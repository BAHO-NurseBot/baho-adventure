// Pin Definitions
const int relay1Pin = 3;  // Relay 1 controls the antenna switch
const int relay2Pin = 4;  // Relay 2 pin
const int relay3Pin = 5;  // Relay 3 pin
const int relay4Pin = 6;  // Relay 4 controls the VCC for antenna
const int buttonPin = 2;  // Button pin

// Timing Variables
unsigned long startTime = 0;  // General timer variable
bool lastButtonState = LOW;   // Last button state for debouncing

// State Variables
enum State { INIT, RELAY4_ON, RELAY1_ON, RELAY1_OFF, RELAY4_OFF, RELAY2_ON, RELAY2_OFF, RELAY3_ON, RELAY3_OFF, ANTENNA_CLOSED, IDLE };
State currentState = INIT;

// State Timing
const unsigned long relay1OnTime = 5000;    // 5 seconds for relay 1
const unsigned long relay2OnTime = 305;    // 0.5 seconds for relay 2
const unsigned long relay3OnTime = 330;    // 0.5 seconds for relay 3
const unsigned long antennaCloseTime = 3000;// 3 seconds for closing the antenna
const unsigned long relay4OnTime = 1000;    // 1 second for relay 4 to stabilize

// Flags
bool antennaClosed = false; // To check if the antenna has been closed

void setup() {
  // Initialize the pins
  pinMode(relay1Pin, OUTPUT);   // Relay 1 (Antenna switch)
  pinMode(relay2Pin, OUTPUT);   // Relay 2
  pinMode(relay3Pin, OUTPUT);   // Relay 3
  pinMode(relay4Pin, OUTPUT);   // Relay 4 (Antenna VCC)
  pinMode(buttonPin, INPUT);    // Button

  // Start with all relays off
  digitalWrite(relay1Pin, HIGH); // Relay 1 off
  digitalWrite(relay2Pin, HIGH); // Relay 2 off
  digitalWrite(relay3Pin, HIGH); // Relay 3 off
  digitalWrite(relay4Pin, HIGH); // Relay 4 off (VCC off)

  // Begin serial communication for debugging
  Serial.begin(9600);
  Serial.println("Antenna Control System Started");
}

void loop() {
  unsigned long currentTime = millis();
  bool currentButtonState = digitalRead(buttonPin);

  // Debounce button press
  if (currentButtonState == HIGH && lastButtonState == LOW) {
    delay(50); // Simple debounce delay
    if (digitalRead(buttonPin) == HIGH) { // Confirm button press
      Serial.println("Button Pressed");
      if (antennaClosed) {
        Serial.println("Restarting System...");
        antennaClosed = false; // Reset the antenna closed flag
        startTime = currentTime;
        currentState = RELAY4_ON; // Start with powering the VCC
      }
    }
  }
  lastButtonState = currentButtonState; // Update last button state

  switch (currentState) {
    case INIT:
      // Automatically start the antenna opening process
      Serial.println("Starting Antenna Opening Process...");
      startTime = currentTime;
      currentState = RELAY4_ON;
      break;

    case RELAY4_ON:
      // Activate Relay 4 to connect VCC to the antenna
      Serial.println("Activating Relay 4 (VCC)...");
      digitalWrite(relay4Pin, LOW); // Activate Relay 4 (LOW to activate)
      startTime = currentTime;
      currentState = RELAY1_ON;
      break;

    case RELAY1_ON:
      // Activate Relay 1 to open the antenna
      if (currentTime - startTime >= relay4OnTime) {
        Serial.println("Activating Relay 1 (Antenna Switch)...");
        digitalWrite(relay1Pin, LOW); // Activate Relay 1 (LOW to activate)
        startTime = currentTime;
        currentState = RELAY1_OFF;
      }
      break;

    case RELAY1_OFF:
      // Deactivate Relay 1 (Switch)
      if (currentTime - startTime >= relay1OnTime) {
        Serial.println("Deactivating Relay 1 (Antenna Switch)...");
        digitalWrite(relay1Pin, HIGH); // Deactivate Relay 1
        Serial.println("Deactivating Relay 4 (VCC)...");
        digitalWrite(relay4Pin, HIGH); // Deactivate Relay 4 (VCC off)
        startTime = currentTime;
        currentState = RELAY2_ON;
      }
      break;

    case RELAY2_ON:
      // Activate Relay 2
      Serial.println("Activating Relay 2...");
      digitalWrite(relay2Pin, LOW); // Activate Relay 2 (LOW to activate)
      startTime = currentTime;
      currentState = RELAY2_OFF;
      break;

    case RELAY2_OFF:
      // Deactivate Relay 2
      if (currentTime - startTime >= relay2OnTime) {
        Serial.println("Deactivating Relay 2...");
        digitalWrite(relay2Pin, HIGH); // Deactivate Relay 2
        currentState = RELAY3_ON;
      }
      break;

    case RELAY3_ON:
      // Wait for Button Press to activate Relay 3
      if (currentButtonState == HIGH) {
        Serial.println("Button Pressed: Activating Relay 3...");
        digitalWrite(relay3Pin, LOW); // Activate Relay 3 (LOW to activate)
        startTime = currentTime;
        currentState = RELAY3_OFF;
      }
      break;

    case RELAY3_OFF:
      // Deactivate Relay 3 and Close Antenna
      if (currentTime - startTime >= relay3OnTime) {
        Serial.println("Deactivating Relay 3...");
        digitalWrite(relay3Pin, HIGH); // Deactivate Relay 3
        Serial.println("Activating Relay 4 (VCC) to Close Antenna...");
        digitalWrite(relay4Pin, LOW); // Activate Relay 4 (VCC on)
        delay(500); // Stabilize VCC for 0.5 seconds
        Serial.println("Activating Relay 1 (Antenna Switch)...");
        digitalWrite(relay1Pin, LOW); // Activate Relay 1 to close antenna
        delay(antennaCloseTime); // Keep Relay 1 on for 3 seconds
        Serial.println("Deactivating Relay 1 (Antenna Switch)...");
        digitalWrite(relay1Pin, HIGH); // Deactivate Relay 1
        Serial.println("Deactivating Relay 4 (VCC)...");
        delay(4000); // Wait 3 seconds
        digitalWrite(relay4Pin, HIGH); // Deactivate Relay 4 (VCC off)
        Serial.println("Antenna Closed");
        antennaClosed = true; // Mark the antenna as closed
        currentState = IDLE; // Return to IDLE state
      }
      break;

    case IDLE:
      // Waiting for the button press to restart the cycle
      break;
  }
}
